package work.statictest;

public class RandomTest {

	public static void main(String[] args) {
		// java.lang.Math#random()
		// java.util.Random class
		System.out.println(">>> ������ ���� ����");
		double data1 =  Math.random() * 100;
		int data2 = (int)data1;
		
		int data = (int)(Math.random() * 100);
		System.out.println(data);
		
	}

}
