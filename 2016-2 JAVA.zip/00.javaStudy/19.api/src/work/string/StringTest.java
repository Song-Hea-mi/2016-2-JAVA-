package work.string;

public class StringTest {

	public static void main(String[] args) {
		// heap area => literal pool
		String msg1 = "hello";
		String msg2 = "hello";
		// heap area
		String msg3 = new String("hello");
		String msg4 = new String("hello");
		String msg5 = new String("HELLO");
		
		System.out.println(msg1 == msg2);  // true
		System.out.println(msg1 == msg3);  // false
		System.out.println(msg1 == msg5);  // false
		
		System.out.println(msg1.equals(msg2));  // true
		System.out.println(msg1.equals(msg3));  // true
		System.out.println(msg1.equals(msg5));  // false : ��ҹ��� ����
		System.out.println(msg1.equalsIgnoreCase(msg5));  // true
		
		StringBuffer data1 = new StringBuffer();
		data1.append("aa");
		data1.append("bb");
		data1.append("cc");
		
		//String data = data1; // ��Ӱ��踦 �̷��� �����Ƿ� �ٸ�Ÿ�� ����
		String data = data1.toString();
		System.out.println(data1);
		
	}

}













