package work.string;

import java.util.StringTokenizer;

public class StringSplitTest {

	public static void main(String[] args) {
		String data1 = "user01, pass01, ȫ�浿";
		String data2 = "user01 pass01 ȫ�浿";
		
		// ���ڿ��� �и�(��ū��)
		// java.lang.String#split()
		// java.util.StringTokenizer Ŭ����
		
		String[] datas1 = data1.split(", ");
		for(String d: datas1) {
			System.out.println(d);
		}
		System.out.println();
		
		StringTokenizer tokens = new StringTokenizer(data1, ", ");
		
		//�Ʒ� �� �ּ� ������ -> java.util.StringTokenizer@15db9742
		//System.out.println(tokens);
		//System.out.println(tokens.toString());
		
		while (tokens.hasMoreTokens()) {
			String data = tokens.nextToken();
			System.out.println(data);
		}
		System.out.println();
		/** 
		 * ## java.lang.String.split()
		 * ## java.util.StringTokenizer
		 */
		String string1 = "�Ƹ޸�ī��, ������, ��ƮƼ";		
		String[] strings1 = string1.split(", ");
		for (String s : strings1) {
			System.out.println(s);
		}
		System.out.println();
		String string2 = "�Ƹ޸�ī��, ������, ��ƮƼ";
		StringTokenizer strings2 = new StringTokenizer(string2, ", ");
		while (strings2.hasMoreTokens()) {
			System.out.println(strings2.nextToken());
		}
		System.out.println();
	}

}
