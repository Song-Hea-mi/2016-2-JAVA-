package work.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.sun.org.apache.xml.internal.dtm.DTMDOMException;

import work.model.dto.Member;

/** 
 * ## DAO(Data Access Object) Pattern
 * -- ȸ�� ���̺�(members)�� ���� DAO Ŭ����
 * -- CRUD(�߰�, ��ȸ, ����, ����) ���
 * @author SWU
 *
 */
public class MemberDao {
	// JDBC Property => �ܺ��ڿ����ϻ��
	private ResourceBundle bundle;
	
	//JDBC property
	private String url; //127.0.0.1 local ip ��ȯ
	private String user;
	private String pass;
	private String driver;

	public MemberDao() {
		// JDBC Property => �ܺ��ڿ����ϻ��=>�ܺ� �ڿ����� ��������
		// �����ڿ�������ġ : src/config/dbserver.properties (eclipse ide)
		// �����ڿ�������ġ : classes/config/dbserver.properties
		String baseName="config/dbserver";
		bundle = ResourceBundle.getBundle(baseName);
		url = bundle.getString(url);
		user = bundle.getString(user);
		pass = bundle.getString(pass);
		driver = bundle.getString(driver);
		//1. JDBC DRIVER �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.getMessage();
		}
	}
	
	public Connection getConnetion() throws SQLException {
		//2. DB �������� (url, user, pass)
		Connection conn = DriverManager.getConnection(url, user, pass);
		return DriverManager.getConnection(url,user,pass);
	}
	
	/** �α��� üũ**/
	public String selectLoginCheck(String userId, String userPw) {
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			stmt = conn.createStatement();
			
			//4. SQL �����ö: �������
			String sql = "select grade from members where user_id=" +sqlStr(userId) + "and user_pw=" + sqlStr(userPw);
			rs = stmt.executeQuery(sql);
			
			//5. ���ó��
			if(rs.next()){
				return rs.getString(1);
			}
		} catch(SQLException e) {
			e.getMessage();
		}
			
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
		return null;
	}
	
	/** ȸ�� ��� ��� */
	public int insertMember(Member dto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			String sql = "insert into members values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getUserId());
			pstmt.setString(2,dto.getUserPw());
			pstmt.setString(3,dto.getUsername());
			pstmt.setString(4,dto.getMobile());
			pstmt.setString(5,dto.getEmail());
			pstmt.setInt(6,dto.getMileage());
			pstmt.setString(7,dto.getEntryDate());
			pstmt.setString(8,dto.getGrade());
			pstmt.setString(9,dto.getManager());
			
			//4. SQL �����ö: �������
			//5. ���ó��
			return pstmt.executeUpdate();
			
		} catch(SQLException e){
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(pstmt != null) {					
				pstmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}	
		return 0;
	}
	
	/** 
	 * �ƱԸ�Ʈ�� ���� ���� sql �������� ��ȯ
	 * @param data
	 * @return ''
	 */
	public String sqlStr(String data) {
		return "'" + data + "'";
	}
	
	/** ��� ȸ���� ��ȯ ��� */
	public int selectGetCount() {
		Connection conn = null;
		Statement stmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			stmt = conn.createStatement();
			
			//4. SQL �����ö: �������
			String sql = "select count(*) from members";
			
			//5. ���ó��
			return sql.length();
			
		} catch(SQLException e) {
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(stmt != null) {
				stmt.close();
			}
			if(conn != null) {
				conn.close();
			}	
		} catch (SQLException e) {
				e.getMessage();
		}	
		return 0;
	}
	
	/** ���̵��� ���� ���� 
	 * @throws SQLException 
	*/
	public boolean selectExistUserId(String userId) throws SQLException {
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			conn = getConnetion();
			stmt = conn.createStatement();
			String sql = "select username from members where user_id=" + sqlStr(userId);
			rs = stmt.executeQuery(sql);
			return rs.next();
		} catch (SQLException e){
			e.getMessage();
		} 
		return false;
	}
	
	/** �ƱԸ�Ʈ�� ���� ȸ���� ������ ������Ʈ */
	public void updateUserInfo(Member dto) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnetion();
			String sql = "update members set "
					+ "user_pw=?, username=?,"
					+ "user_grade=?, mobile=?,"
					+ "email=?, entryDate=?,"
					+ "grade=?, mileage=?, manager=?"
					+ "where user_id="+sqlStr(dto.getUserId());
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);
			
		} catch (SQLException e){
			e.getMessage();
		} 	
	}
	
	/** �ƱԸ�Ʈ�� ���� ���̵� ���� ��� ��ü�� ��ȯ�ϴ� �޼��� */
	public Member selectOne(String userId) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			String sql = "select * from members where user_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery(sql);
			if (rs.next()) {
				String userPw = rs.getString("user_pw");
				String username = rs.getString("username");
				String mobile = rs.getString("mobile");
				String email = rs.getString("email");
				String entryDate = rs.getString("emtry_date");
				String grade = rs.getString("grade");
				int mileage = rs.getInt("mileage");
				String manager = rs.getString("manager");
				return new Member(userId, userPw, username, mobile, entryDate, grade, manager);
			}
		} catch(SQLException e) {
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(pstmt != null) {
				pstmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
		return null;
	}
	
	/** ��üȸ��������ȸ */
	public ArrayList<Member> selectList() {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		ArrayList<Member> list = new ArrayList<Member>();
		try {
			//2. DB ��������
			conn = getConnetion();
			String sql = "select * from members";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);
			Member dto = null;
			while (rs.next()) {
				String userId = rs.getString("userId");
				String userPw = rs.getString("user_pw");
				String username = rs.getString("username");
				String mobile = rs.getString("mobile");
				String email = rs.getString("email");
				String entryDate = rs.getString("emtry_date");
				String grade = rs.getString("grade");
				int mileage = rs.getInt("mileage");
				String manager = rs.getString("manager");
				dto = new Member(userId, userPw, username, mobile, entryDate, grade, manager);
				list.add(dto);
			}
		} catch(SQLException e) {
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(pstmt != null) {
				pstmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
		return list;
	}
	
	/** ��޺�ȸ��������ȸ */
	public ArrayList<Member> selectList(String grade) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		ArrayList<Member> list = new ArrayList<Member>();
		try {
			//2. DB ��������
			conn = getConnetion();
			String sql = "select * from members where grade=?";
			pstmt.setString(7, grade);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);
			Member dto = null;
			while (rs.next()) {
				String userId = rs.getString("userId");
				String userPw = rs.getString("user_pw");
				String username = rs.getString("username");
				String mobile = rs.getString("mobile");
				String email = rs.getString("email");
				String entryDate = rs.getString("emtry_date");
				int mileage = rs.getInt("mileage");
				String manager = rs.getString("manager");
				dto = new Member(userId, userPw, username, mobile, entryDate, grade, manager);
				list.add(dto);
			}
		} catch(SQLException e) {
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(pstmt != null) {
				pstmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
		return list;
	}
	
}
