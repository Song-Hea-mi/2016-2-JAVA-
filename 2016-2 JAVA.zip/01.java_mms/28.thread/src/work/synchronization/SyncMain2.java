package worksynchronization;

/** 
synchronized ������ ����ȭ ����(�Ǵٸ� ���) 
**/ 
class Bank2{ 
    private int money = 10000; //���� �ܾ� 
    public int getMoney(){ 
        return this.money; 
    } 
    public void setMoney(int money){ 
        this.money = money; 
    } 
    public void saveMoney(int save){ 
        int m = this.getMoney(); 
        try{ 
            Thread.sleep(3000); 
        }catch(InterruptedException e){e.printStackTrace();} 
        this.setMoney(m + save); 
    } 
    public void minusMoney(int minus){ 
        int m = this.money; 
        try{ 
            Thread.sleep(200); 
        }catch(InterruptedException e){e.printStackTrace();} 
        this.setMoney(m - minus); 
    } 
} //end of Bank2 class 

class Park2 extends Thread{ 
    public void run(){ 
        synchronized(SyncMain2.myBank2){ 
            SyncMain2.myBank2.saveMoney(3000);  
        } 
        System.out.println("saveMoney(3000):" + SyncMain2.myBank2.getMoney()); 
         
    } 
} //end of Park2 class 

class Park2Wife2 extends Thread{ 
    public void run(){ 
        synchronized(SyncMain2.myBank2){ 
            SyncMain2.myBank2.minusMoney(5000);  
        } 
        System.out.println("minusMoney(5000):" + SyncMain2.myBank2.getMoney()); 
    } 
} //end of Park2Wife2 class 

public class SyncMain2{ 
    public static Bank2 myBank2 = new Bank2(); 
    public static void main(String[] args) throws Exception{ 
        Park2 p = new Park2(); 
        Park2Wife2 w = new Park2Wife2(); 
        p.start(); 
        try{ 
            Thread.sleep(200); 
        }catch(InterruptedException e){e.printStackTrace();} 
        w.start(); 
    } //end of main 
} //end of SyncMain2 class 
