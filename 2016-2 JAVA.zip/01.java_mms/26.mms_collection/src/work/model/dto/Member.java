/**
 * 
 */
package work.model.dto;

import work.util.Utility;

/**
 * <pre>
 * ȸ�� �𵨸� Ŭ����
 * -- domain class
 * -- encapsulation
 * {@link java.lang.Object#toString()}
 * {@link java.lang.Object#equals(Object)}
 * {@link java.lang.Object#hashCode()}
 * -- constructor overloading
 * </pre>
 * @see work.view.Test
 * @see java.lang.String#length()
 * @since jdk1.4
 * @version ver.1.0
 * @author SWU
 */

/**
 * 
 */
public class Member {
	/** ȸ�� ���̵� ���� */
	private String userId;
	/** ȸ�� ��й�ȣ ����*/
	private String userPw;
	/** ȸ���̸� ����*/
	private String username;
	/** ȸ�� ����ó ����*/
	private String mobile;
	/** ȸ�� �̸��� ����*/
	private String email;
	/** ȸ�� ������ ����*/
	private String entryDate;
	/** ȸ�� ��� ����*/
	private String grade;
	/** ȸ�� ���ϸ��� ����*/
	private int mileage;
	/** ȸ�� ����� ����*/
	private String manager;
	/**
	 * @param userId
	 * @param userPw
	 * @param username
	 * @param mobile
	 * @param email
	 */
	public Member() {
	}
	
	
	public Member(String userId, String userPw, String username, String mobile, String email) {
		this.userId = userId;
		this.userPw = userPw;
		this.username = username;
		this.mobile = mobile;
		this.email = email;
	}
	
	/** �Ϲ�ȸ��
	 * @param userId
	 * @param userPw
	 * @param username
	 * @param mobile
	 * @param email
	 * @param entryDate
	 * @param grade
	 * @param mileage
	 */
	public Member(String userId, String userPw, String username, String mobile, String email, String entryDate,
			String grade, int mileage) {
		this(userId, userPw, username, mobile, email);
		this.entryDate = entryDate;
		this.grade = grade;
		this.mileage = mileage;
	}
	
	/** ���ȸ��
	 * @param userId
	 * @param userPw
	 * @param username
	 * @param mobile
	 * @param email
	 * @param entryDate
	 * @param grade
	 * @param manager
	 */
	public Member(String userId, String userPw, String username, String mobile, String email,String entryDate,String grade, String manager) {
		this(userId, userPw, username, mobile, email);
		this.entryDate = entryDate;
		this.grade = grade;
		this.manager = manager;
	}
	
	/** ������ ȸ��
	 * @param userId
	 * @param userPw
	 * @param username
	 * @param mobile
	 * @param email
	 * @param entryDate
	 * @param grade
	 */
	public Member(String userId, String userPw, String username, String mobile, String email,String entryDate,String grade) {
		this(userId, userPw, username, mobile, email);
		this.entryDate = entryDate;
		this.grade = grade;
	}
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the userPw
	 */
	public String getUserPw() {
		return userPw;
	}
	/**
	 * @param userPw the userPw to set
	 */
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the entryDate
	 */
	public String getEntryDate() {
		return entryDate;
	}
	/**
	 * @param entryDate the entryDate to set
	 */
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}
	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}
	/**
	 * @return the mileage
	 */
	public int getMileage() {
		return mileage;
	}
	/**
	 * @param mileage the mileage to set
	 */
	public void setMileage(int mileage) {
		this.mileage = mileage;
	}
	/**
	 * @return the manager
	 */
	public String getManager() {
		return manager;
	}
	/**
	 * @param manager the manager to set
	 */
	public void setManager(String manager) {
		this.manager = manager;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		// if (obj.getClass().isInstance((Object)getClass())) //������ ����
		// if (obj instanceof Member) 
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Member userId=");
		builder.append(userId);
		builder.append(", userPw=");
		builder.append(userPw);
		builder.append(", username=");
		builder.append(username);
		builder.append(", mobile=");
		builder.append(mobile);
		builder.append(", email=");
		builder.append(email);
		builder.append(", entryDate=");
		builder.append(entryDate);
		builder.append(", grade=");
		builder.append(grade);
		builder.append(", mileage=");
		builder.append(Utility.getCurrentDate());
		builder.append(", manager=");
		builder.append(manager);
		return builder.toString();
	}
	
	
}
