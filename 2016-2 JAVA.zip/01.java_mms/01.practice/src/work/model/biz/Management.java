package work.model.biz;

public class Management {

}
