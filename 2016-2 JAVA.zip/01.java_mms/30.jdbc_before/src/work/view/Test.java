/**
 * 
 */
package work.view;

import java.io.IOException;
import java.sql.SQLException;

import work.model.dto.Member;
import work.util.Utility;

/**
 * @author PC
 *
 */
public class Test {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		try {
			Menu menu = new Menu();
			menu.initMenu();
		} catch(IOException e) {
			System.out.println("Error: " + e.getMessage());
		} 		
	} 
}









