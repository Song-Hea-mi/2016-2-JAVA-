package work.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import work.model.dto.Member;

/** 
 * ## DAO(Data Access Object) Pattern
 * -- ȸ�� ���̺�(members)�� ���� DAO Ŭ����
 * -- CRUD(�߰�, ��ȸ, ����, ����) ���
 * @author SWU
 *
 */
public class MemberDao {
	//JDBC property
	private String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE"; //127.0.0.1 local ip ��ȯ
	private String user = "hr";
	private String pass = "tiger";
	private String driver = "oracle.jdbc.driver.OracleDriver";
	
	public MemberDao() {
		//1. JDBC DRIVER �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.getMessage();
		}
	}
	
	public Connection getConnetion() throws SQLException {
		//2. DB �������� (url, user, pass)
		Connection conn = DriverManager.getConnection(url, user, pass);
		return DriverManager.getConnection(url,user,pass);
	}
	
	/** �α��� üũ**/
	public String selectLoginCheck(String userId, String userPw) {
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			stmt = conn.createStatement();
			
			//4. SQL �����ö: �������
			String sql = "select username from members where user_id=" +sqlStr(userId) + "and user_pw=" + sqlStr(userPw);
			rs = stmt.executeQuery(sql);
			
			//5. ���ó��
			if(rs.next()){
				return rs.getString(1);
			}
		} catch(SQLException e) {
			e.getMessage();
		}
			
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
		return null;
	}
	
	/** ȸ�� ��� ��� */
	public int insertMember(Member dto) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			String sql = "insert into members values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getUserId());
			pstmt.setString(2,dto.getUserPw());
			pstmt.setString(3,dto.getUsername());
			pstmt.setString(4,dto.getMobile());
			pstmt.setString(5,dto.getEmail());
			pstmt.setString(6,dto.getEmail());
			pstmt.setString(7,dto.getEntryDate());
			pstmt.setString(8,dto.getGrade());
			pstmt.setString(9,dto.getManager());
			
			//4. SQL �����ö: �������
			//5. ���ó��
			return pstmt.executeUpdate(sql);
			
		} catch(SQLException e){
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(pstmt != null) {					
				pstmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}	
		return 0;
	}
	
	/** 
	 * �ƱԸ�Ʈ�� ���� ���� sql �������� ��ȯ
	 * @param data
	 * @return ''
	 */
	public String sqlStr(String data) {
		return "'" + data + "'";
	}
	
	/** ��� ȸ���� ��ȯ ��� */
	public int selectGetCount() {
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			//2. DB ��������
			conn = getConnetion();
			
			//3. SQL ��ΰ���: 
			stmt = conn.createStatement();
			
			//4. SQL �����ö: �������
			String sql = "select count(*) from members";
			
			//5. ���ó��
			if(rs.next()){
				return sql.length();
			}
		} catch(SQLException e) {
			e.getMessage();
		}
		//6. �ڿ� ����
		try {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if(conn != null) {
				conn.close();
			}	
		} catch (SQLException e) {
				e.getMessage();
		}	
			
		return 0;
	}
	
	/** ���̵��� ���� ���� 
	 * @throws SQLException 
	*/
	public boolean selectExistUserId(String userId) throws SQLException {
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			conn = getConnetion();
			stmt = conn.createStatement();
			String sql = "select username from members where user_id=" + sqlStr(userId);
			rs = stmt.executeQuery(sql);
			return rs.next();
			
		} catch (SQLException e){
			e.getMessage();
		} 
		return false;
	}
	
}
