/**
 * 
 */
package work.view;

import java.io.IOException;

import work.model.dto.Member;
import work.util.Utility;

/**
 * @author PC
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Menu menu = new Menu();
			menu.initMenu();
		} catch(IOException e) {
			System.out.println("Error: " + e.getMessage());
		} 		
	} 
}









