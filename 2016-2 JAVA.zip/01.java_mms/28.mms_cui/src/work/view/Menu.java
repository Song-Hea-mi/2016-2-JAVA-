/** 
 * ȸ�������ý��� ȭ�� ����
 */
package work.view;
//
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import work.model.biz.ManagementArray;
import work.model.dto.Member;

public class Menu {
	/** ���� �α��� ȸ���� ��� ���� */
	private static String authorGrade;
	/** ���� �α��� ȸ���� ���̵� ���� */
	private static String authorId;
	/** ���� ����� ��ü���� */
	ManagementArray mng = new ManagementArray();
	/** ���δ��� �б����� ��Ʈ�� ���� */
	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
	public void initMemberLoadFile() throws IOException {
		 //������ ���; ���� ���� : eclipse=>������Ʈ ����
		File initMemberFile = new File("member.txt");
		String info = null;
		StringTokenizer tokens = null;
		
		Member dto = null;
		String userId = null;
		String userPw = null;
		String username = null;
		String mobile = null;
		String email = null;
		String entryDate = null;
		String grade = null;
		
		int mileage = 0;
		String manager = null;
		
		if (initMemberFile.exists()) {
			BufferedReader in = new BufferedReader(new FileReader(initMemberFile));
			while ((info = in.readLine()) != null) {
				tokens = new StringTokenizer(info, ", ");
			}
		}
	}
	
	public void initMemberLoadObject() throws IOException, ClassNotFoundException {
		 //������ ���; ���� ���� : eclipse => ������Ʈ ����
		File initMemberFile = new File("memberObject.txt");
		if (initMemberFile.exists()) {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("memberObject.txt"));
			ArrayList<Member> members = (ArrayList<Member>)(in.readObject());
			// Management Ŭ������ addMember(Member) : ����ȸ�����
			// Management Ŭ������ addMember(ArrayList<Member>) : ����ȸ�����, ��ġ���
			mng.addMember(members);
		}
	}
	
	
	public Menu() throws IOException, ClassNotFoundException {
		initMemberLoadObject();
	}
	
	/** ���� �޴� ȭ�� */
	public void initMenu() throws IOException {
		System.out.println("==============================");
		System.out.println("1. join");
		System.out.println("2. log-in");
		System.out.println("3. search Id");
		System.out.println("4. search Pw");
		System.out.println("0. exit program");
		System.out.println("==============================");
		System.out.print("command: ");
		int menuNo = Integer.parseInt(in.readLine());
		System.out.println();
		//�޴� ��ȣ�� ���� �޼��� ����
		switch (menuNo) {
			case 1:
				System.out.println("1. join");
				System.out.println("==============================");
				signUpMenu();
				break;
			case 2:
				System.out.println("2. log-in");
				System.out.println("==============================");
				logInMenu();
				break;
			case 3:
				System.out.println("3. search Id");
				System.out.println("==============================");
				findIdMenu();
				break;
			case 4:
				System.out.println("4. search Pw");
				System.out.println("==============================");
				findPwMenu();
				break;
			case 9:
				exitMenuObject();
				break;
			case 0:
				exitMenuObject();
				break;
			default:
				System.out.println("choose number, 0~4");
		}
	}
	
	/** ȸ�� �޴� ȭ�� */
	public void memberMenu() throws IOException {
		System.out.println("==============================");
		System.out.println("1. my Info");
		System.out.println("2. change Info");
		System.out.println("3. change Pw");
		System.out.println("0. log-out");
		System.out.println("==============================");
		System.out.print("command: ");
		int menuNo = Integer.parseInt(in.readLine());
		System.out.println();
		//�޴� ��ȣ�� ���� �޼��� ����
		switch (menuNo) {
			case 1:
				System.out.println("1. my Info");
				System.out.println("==============================");
				printMemberInfo();
				break;
			case 2:
				System.out.println("2. change Info");
				System.out.println("==============================");
				
				break;
			case 3:
				System.out.println("3. change Pw");
				System.out.println("==============================");
				findIdMenu();
				break;
			case 0:
				System.out.println("0. log-out");
				System.out.println("==============================");
				
				break;
			default:
				System.out.println("choose number, 0~3");
		}
	}
	
	/** ȸ�������� ���� �޼��� */
	public void signUpMenu() throws IOException {
		System.out.print("Id: ");
		String userId = in.readLine();
		System.out.print("Pw: ");
		String userPw = in.readLine();
		System.out.print("name: ");
		String username = in.readLine();
		System.out.print("mobile: ");
		String mobile = in.readLine();
		System.out.print("email: ");
		String email = in.readLine();
		//�Է¹��� ȸ�� ������ management ȸ����� ��û
		if (mng.addMember(userId, userPw, username, mobile, email)) {
			//ȸ������ �Ϸ��� ����
			System.out.println("your membership is ompleted, you can use your membership after log-in\n");
			initMenu();
		}
		//ȸ������ ����
		else {
			System.out.println("your membership is not completed, please try again..\n");
			initMenu();
		}
	}
	
	/** �α����� ���� �޼��� */
	public void logInMenu() throws IOException {
		System.out.print("Id: ");
		String userId = in.readLine();
		System.out.print("Pw: ");
		String userPw = in.readLine();
		if (mng.loginCheck(userId, userPw) != null) {
			authorId = userId;
			authorGrade = mng.loginCheck(userId, userPw);
			System.out.println("welcome " + userId + "!\n");
			System.out.println("==============================");
			System.out.println("Id: " + authorId + ", grade: " + authorGrade);
			memberMenu();
			return;
		} 
		System.out.println("there is no information, please check again..\n\n");
		initMenu();
	}
	
	/** ���̵� ã������ �޼��� */
	public void findIdMenu() throws IOException {
		System.out.print("name: ");
		String username = in.readLine();
		System.out.print("email: ");
		String email = in.readLine();
		System.out.println("==============================");
		if(mng.checkId(username, email) != null) {
			System.out.println("your id is " + mng.checkId(username, email) + "..\n");
		} 
		else {
			System.out.println("there is no information, please check again..\n");
		}
		initMenu();
	}
	
	/** ��й�ȣ�� ã�� ���� �޼���; �ӽ� ��й�ȣ �߱� */
	public void findPwMenu() throws IOException {
		System.out.print("id: ");
		String userId = in.readLine();
		System.out.print("mobile: ");
		String mobile = in.readLine();
		System.out.println("==============================");
		if (mng.checkPw(userId, mobile) != null) {
			System.out.println("your temp pw is " +  mng.checkPw(userId, mobile) + ", \n"
					+ "you can change your pw in 'change pw' menu..");
		}
		else {
			System.out.println("there is no information, please check again..\n");
		}
		initMenu();
	}
	
	/** ȸ���� ��������� ���� �޼��� */
	public void printMemberInfo() {
		System.out.println("id: " + mng.getMember(authorId).getUserId());
		System.out.println("pw: " + mng.getMember(authorId).getUserPw());
		System.out.println("name: " + mng.getMember(authorId).getUsername());
		System.out.println("mobile: " + mng.getMember(authorId).getMobile());
		System.out.println("email: " + mng.getMember(authorId).getEmail());
		System.out.println("entryDate: " + mng.getMember(authorId).getEntryDate());
		System.out.println("grade: " + mng.getMember(authorId).getGrade());
		switch (authorGrade) {
			case "G":
				System.out.println("mileage: " + mng.getMember(authorId).getMileage());
				break;
			case "S":
				System.out.println("manager: " + mng.getMember(authorId).getManager());
				break;
		}
	}
	
	/** ȸ������ ������ ���� �޼���*/
	public void changeMemberInfo() throws IOException {
		System.out.println("please input your password..");
		String userPw = in.readLine(); 
		if (mng.isExistPw(userPw) != -1) {
			System.out.println("please input your new information");
			String[] input = new String[5];
			input[] = in.readLine();
			userPw = in.readLine();
			String username = in.readLine();
			String mobile = in.readLine();
			String email = in.readLine();
			mng.isNull(userId)
			updateMember();
		}
		System.out.println("there is no information, please check again..\n");
		memberMenu();
	}
	
	public void exitMenuObject() throws IOException {
		//���� ����� ȸ���� ������ ���� ������� ��Ʈ�� ����
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("memberObject.txt"));
		out.writeObject(mng.getMember());
		out.close();
		//PrintWriter out = new PrintWriter(new FileWriter("member.txt", false));
		//ArrayList<Member> members = mng.getMember(); 
		//for (int i=0; i<members.size(); i++) {
		//	out.println(members.get(i)); //toString get ����� ����
		//}
		System.exit(0);
	}
	
	public void exitMenuFile() throws IOException {
		//���� ����� ȸ���� ������ ���� ������� ��Ʈ�� ����
		PrintWriter out = new PrintWriter(new FileWriter("member.txt", false));
		ArrayList<Member> members = mng.getMember(); 
		for (int i=0; i<members.size(); i++) {
			out.println(members.get(i)); //toString get ����� ����
		}
		System.exit(0);
	}
	
}
