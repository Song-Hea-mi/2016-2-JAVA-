/**
 * 
 */
package work.view;

import java.io.IOException;
import java.util.ArrayList;

import work.model.biz.ManagementArray;
import work.model.dto.Member;
/**
 * @author SWU
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Menu menu = new Menu();
			menu.initMenu();
		} catch (IOException e){
			System.out.println("EROR: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("EROR: " + e.getMessage());
		}
	}
	
}
