package work.set;

import java.util.Date;
import java.util.HashSet;

import work.model.dto.Member;

public class HashSetTest {

	public static void main(String[] args) {
		
		HashSet set = new HashSet();
		
		//��� : add(object) : boolean
		System.out.println(set.add("hello")); //true
		System.out.println(set.add("hello")); //false
		System.out.println(set.add("hello")); //false
		System.out.println(set.add("22")); //true //�⺻���� �ڵ����� ��üŸ������ ����ȯ => Integer
		System.out.println(set.add(new Date()));
		System.out.println(set.add(new Member()));
		System.out.println(set.add(new Member("user01","pass01","ȫ�浿", "010-2434-5656", "goa1248@naver.com")));
		System.out.println(set.add(new Member("user01","pass01","ȫ�浿", "010-2434-5656", "goa1248@naver.com")));
		System.out.println(set.add(new Member("user01","pass01","ȫ�浿", "010-2434-5656", "goa1248@naver.com")));
		System.out.println(set.size());
		
		//ũ�� ��ȸ
		System.out.println(set.size());
		
		//����, ��ȸ => ���� api �߰� ��� =>Interator => Collection �ܹ��� �˻�
		
		//���� remove(Object)
		System.out.println(set.remove("hello"));
		System.out.println(set.remove(new Date()));
		System.out.println(set.remove(new Member("user01","pass01","ȫ�浿", "010-2434-5656", "goa1248@naver.com")));
		//ũ�� ��ȸ
		System.out.println(set.size());
		
	}
}
