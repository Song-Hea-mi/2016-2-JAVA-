package work.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class FactoryDao {
	private static FactoryDao instance = new FactoryDao(); 

	// JDBC Property => �ܺ��ڿ����ϻ��
	private ResourceBundle bundle;
	
	//JDBC property
	private String url; //127.0.0.1 local ip ��ȯ
	private String user;
	private String pass;
	private String driver;
	
	private FactoryDao() {
		// JDBC Property => �ܺ��ڿ����ϻ��=>�ܺ� �ڿ����� ��������
		// �����ڿ�������ġ : src/config/dbserver.properties (eclipse ide)
		// �����ڿ�������ġ : classes/config/dbserver.properties
		String baseName="config/dbserver";
		bundle = ResourceBundle.getBundle(baseName);
		url = bundle.getString(url);
		user = bundle.getString(user);
		pass = bundle.getString(pass);
		driver = bundle.getString(driver);
		
		//1. JDBC DRIVER �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.getMessage();
		}
	}
	
	public Connection getConnetion() throws SQLException {
		//2. DB �������� (url, user, pass)
		Connection conn = DriverManager.getConnection(url, user, pass);
		return DriverManager.getConnection(url,user,pass);
	}
	
	
	public void close(ResultSet rs, Statement stmt, Connection conn) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
				e.getMessage();
		}
	}
	
	public void close(Statement stmt, Connection conn) {
		close(null, stmt, conn);
	}
	public static FactoryDao getInstance() {
		return instance;
	}
}
